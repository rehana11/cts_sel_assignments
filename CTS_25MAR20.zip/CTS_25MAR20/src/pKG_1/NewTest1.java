package pKG_1;

//public class NewTest1 {

import org.testng.Assert;
import org.testng.annotations.Test;

public class NewTest1 {
	lontestcase1 demoweb;
  @Test
  public void test1() {
	  
	  String act_res;
	  String exp_res = "rehana.usen@gmail.com";
	  demoweb = new lontestcase1();
	  
	  act_res = demoweb.login();
	  
	  Assert.assertEquals(act_res,exp_res);
  }
}
	
