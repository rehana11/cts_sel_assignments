package tests;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages1.Home_page1;
import pages1.Login_page1;
import pages1.Profile_page1;

public class Test2 {
	WebDriver dr;
	Home_page1 hp;
	Login_page1 lp;
	Profile_page1 pp;
	
	
	@BeforeClass
	public void launchbrowser() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		//WebDriver dr = new ChromeDriver();
		 dr = new ChromeDriver();
		dr.get("http://www.saucedemo.com/");
		 hp=new Home_page1(dr);
		 lp=new Login_page1(dr);
		 pp =new Profile_page1(dr);
	}
	@Test
	public void logintest1() {
		//String exp_pn = "Products",act_pn;
		
		//dr.findElement(By.className("product_label")).getText();
		
		hp.click_login_link();
		lp.do_login("standard_user", "secret_sauce");
		
		String expTitle = "Swag Labs";
		String  actTitle = dr.getTitle();
		System.out.println("act_pn1:"+actTitle);
		Assert.assertEquals(expTitle, actTitle);
		
	dr.getTitle();
		
		
		String exp_pn = "Products",act_pn;
		act_pn = pp.get_profilename();
		System.out.println("act_pn : "+ act_pn);
		Assert.assertEquals(act_pn , exp_pn);
		
		
		
		
	}
	@AfterClass
	public void closebrowser() {	
		dr.close();
	}
	

}

