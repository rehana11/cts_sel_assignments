package KWDFW;

public class test2 {
	public static  void main(String[] args) {
		excel_opertaion  excel = new excel_opertaion();
		String data = excel.read_excel(0,0);
		
		
		
		
	}
	

	
	
}


