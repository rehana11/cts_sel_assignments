package DDFW;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class data_pro_login {
	
	public String login(String uid,String pwd) {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		
		WebDriver dr= new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();;
		dr.findElement(By.id("Email")).sendKeys(uid);
		dr.findElement(By.id("Password")).sendKeys(pwd);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		String b=dr.findElement(By.className("account")).getText();
		dr.close();
		return b;
		
		
		
		
		
	}

}

