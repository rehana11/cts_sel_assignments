package pages1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login_page1{
	WebDriver dr2;
	By eid = By.id("user-name");
	By pwd = By.id("password");
	By login_btn = By.className("btn_action");
	public Login_page1(WebDriver dr)
	{
		this.dr2=dr;
	}

	public void enter_username_id(String username) {
		
		dr2.findElement(eid).sendKeys(username);
	}
	
	public void enter_password(String password)
	{
		dr2.findElement(pwd).sendKeys(password);
	}
	public void click_login_btn()
	{
		dr2.findElement(login_btn).click();
	}
	public void do_login(String username,String password) {
		this.enter_username_id(username);
		this.enter_password(password);
		this.click_login_btn();
	}
}