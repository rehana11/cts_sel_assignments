package pKG_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class lontestcase1 {
	public String login() {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver  = new ChromeDriver();
		driver.get("http://demowebshop.tricentis.com/");
		

			Actions action =new Actions(driver) ;
			WebElement element =driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a"));
			action.moveToElement(element).click().perform();
			driver.findElement(By.id("Email")).sendKeys("rehana.usen@gmail.com");
			driver.findElement(By.id("Password")).sendKeys("taslimusen");
			driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
			//System.out.println("text match");
		
		String act_res = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		
return act_res;
	}
}
