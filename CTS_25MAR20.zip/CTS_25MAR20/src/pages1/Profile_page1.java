package pages1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Profile_page1 {
	
	By  xp_Profilename1 = By.className("login_logo");
	By  xp_Profilename = By.className("product_label");
	WebDriver dr3;
	
	 public Profile_page1(WebDriver dr) {
		dr3=dr;
	 }  
	 
	public String get_profilename1() {
		String pname1= dr3.findElement(xp_Profilename1).getText();
		return pname1;
	
	 }
	 
	 
	 public String get_profilename() 
	 {
		 
		 String pname = dr3.findElement(xp_Profilename).getText();
		 return pname;
	 }
	 

}
