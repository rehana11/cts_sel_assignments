package pages1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Home_page1 {
	 WebDriver dr1; 
	  
	  public Home_page1(WebDriver dr) {
		  this.dr1=dr;
	  }
	  
		By login_link = By.id("user-name");
		By register_link = By.id("password");
		
		public void click_register_link()
		{
			dr1.findElement(register_link).click();
		} 
		
		public void click_login_link() {
			
			dr1.findElement(login_link).click();
		}

}
