package DDFW1;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import DDFW.data_pro_login;

import org.junit.BeforeClass;
import org.testng.annotations.DataProvider;

public class data_login_xl  extends excel_io_arr{
	data_pro_login test;
	@BeforeClass
	public void get_data() {
		
		get_test_data();
	}
	@Test(dataProvider ="login_data")
public void login(String eid ,String pwd,String expid) {
		
		test = new data_pro_login ();
		String actid = test.login(eid,pwd);
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(actid, expid);
		sa.assertAll();
		System.out.println("email :"+eid+"ped:"+pwd);
	}
	@DataProvider(name="login_data")
	public String[][] provide_data()  
		{
			return testdata;
		}
	}

