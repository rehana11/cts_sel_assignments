package Testng_1;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest6 {
  @Test
  public void t1() {
	  
	  String er="chennai",ar="chennai1";
	  System.out.println("in test method t1");
	  SoftAssert sa = new SoftAssert();
	  
	  sa.assertEquals("asd", "asd");
	  sa.assertAll();
  }
  @Test
  public void t2() {
	  String er ="chennai",ar="chennai1";
	  
	  System.out.println("in test method t2");
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(er, ar);
	  sa.assertAll();
  }
}
