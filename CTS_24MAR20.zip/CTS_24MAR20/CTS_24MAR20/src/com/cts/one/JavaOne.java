package com.cts.one;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class JavaOne {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
WebDriver driver  = new ChromeDriver();
driver.get("http://demowebshop.tricentis.com/");
if(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[1]/a/img")).isDisplayed())
{

	Actions action =new Actions(driver) ;
	WebElement element =driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a"));
	action.moveToElement(element).click().perform();
	driver.findElement(By.id("Email")).sendKeys("rehana.usen@gmail.com");
	driver.findElement(By.id("Password")).sendKeys("taslimusen");
	driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	System.out.println("text match");
	}
else
	{
		System.out.println("text not match");
		//String expTitle = "amzon";
		//String actTitle = driver.getTitle();
		//Assert.assertEquals(expTitle,actTitle);
		
	}
 if(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).isDisplayed()) {
	 System.out.println("email id is verified");
	 
 }
	
}}

