package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.HOME_PAGE;
import pages.LOGIN_PAGE;

public class Test1 {
	WebDriver dr;
	HOME_PAGE hp;
	LOGIN_PAGE lp;
	
	@BeforeClass
	public void launchbrowser() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		//WebDriver dr = new ChromeDriver();
		 dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		 hp=new HOME_PAGE(dr);
		 lp=new LOGIN_PAGE(dr);
	}
	@Test
	public void logintest1() {
		hp.click_login_link();
		lp.do_login("rehana.usen@gmail.com", "taslimusen");
		
	}
	@AfterClass
	public void closebrowser() {
		dr.close();
	}
	

}
