package DDFW;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class data_login {
	data_pro_login test;
	@Test( dataProvider= "login_data")
	public void login(String eid ,String pwd,String expid) {
		
		test = new data_pro_login ();
		String actid = test.login(eid,pwd);
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(actid, expid);
		sa.assertAll();
		System.out.println("email :"+eid+"ped:"+pwd);
	}
	@DataProvider(name="login_data")
	public String[][] provide_data() {
		 String[][] testdata= {
				 
				 {"rehana.usen@gmail.com","taslimusen","rehana.usen@gmail.com"},
				 {"rehana.usen@gmail.com","taslimusen","rehana.usen12@gmail.com"},
		 };return testdata;
	}
	
	
	

}
